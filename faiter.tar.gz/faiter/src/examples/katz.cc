#include "client/client.h"


using namespace dsm;

DECLARE_string(result_dir);
DECLARE_int64(num_nodes);
DECLARE_double(portion);
DECLARE_int64(katz_source);
DECLARE_double(katz_beta);
DECLARE_int32(shards);


struct KatzIterateKernel : public IterateKernel<int, float, vector<int> > {
    
    float zero;
    float s_value;

    KatzIterateKernel() : zero(0), s_value(1000000){}

    void read_data(string& line, int& k, vector<int>& data){
        string linestr(line);
        int pos = linestr.find("\t");
        int source = boost::lexical_cast<int>(linestr.substr(0, pos));

        vector<int> linkvec;
        string links = linestr.substr(pos+1);
        int spacepos = 0;
        while((spacepos = links.find_first_of(" ")) != links.npos){
            int to;
            if(spacepos > 0){
                to = boost::lexical_cast<int>(links.substr(0, spacepos));
            }
            links = links.substr(spacepos+1);
            linkvec.push_back(to);
        }

        k = source;
        data = linkvec;
    }

    void read_checkpoint(string& line, int& k, float& v){ 
        string linestr(line);
        int pos = linestr.find("\t");
        if(pos == -1) return;
        
        k = boost::lexical_cast<int>(linestr.substr(0, pos));
        v = boost::lexical_cast<float>(linestr.substr(pos+1));
        //v = 0.0;
        //cout << "read_ck v" << k << "=" << v << endl;
    }
    
    void init_c(const int& k, float& delta, vector<int>& data){
        if(k == FLAGS_katz_source){
            delta = s_value;
        }else{
            delta = zero;
        }
    }
    
    void init_v(const int& k,float& v,vector<int>& data){
        v=zero;  
    }

    void accumulate(float& a, const float& b){
        a = a + b;
    }

    void priority(float& pri, const float& value, const float& delta){
        pri = abs(delta);
    }

    void g_func(const int& k,const float& delta, const float&value, const vector<int>& data, vector<pair<int, float> >* output){
        if (delta == zero) {
            return;
        }
        
        float outv = FLAGS_katz_beta * delta;
        for(vector<int>::const_iterator it=data.begin(); it!=data.end(); it++){
            int target = *it;
            output->push_back(make_pair(target, outv));
        }
    }

    const float& default_v() const {
        return zero;
    }
    
    //add by wzg, only used in fault-tolerance, send original messages instead of delta_v, TODO
    void fc_func(const int& k,const float& delta,const float& value, const vector<int>& data, vector<pair<int, float> >* output) {
        if (value == zero) {
            return;
        }
        
        float outv = FLAGS_katz_beta * value;
        for(vector<int>::const_iterator it=data.begin(); it!=data.end(); it++) {
            int target = *it;
            output->push_back(make_pair(target, outv));
            //cout << "fc_send " << outv << " from v" << k << " to v" << target << endl;
        }
    }
  
    //add by wzg, only used in fault-tolerance, TODO
    void fc_recover_delta_v(const int& k, float& delta, float& value) {
        float tmp_v = delta; 
        if(k == FLAGS_katz_source){
            tmp_v = tmp_v + s_source;
        }
        delta = tmp_v - value;
        //cout << "fc_v" << k << ", old=" << value << ", new=" << tmp_v << ", delta=" << delta << endl;
    }
};

/**
 * K=int, V=float
 */
  struct KatzTermChecker : public TermChecker<int, float> {
    double last;
    double curr;
    
    KatzTermChecker(){
        last = -std::numeric_limits<double>::max();
        curr = 0;
    }

    double set_curr(){
        return curr;
    }
    
    double estimate_prog(LocalTableIterator<int, float>* statetable){
        double partial_curr = 0;
        double defaultv = statetable->defaultV();
        while(!statetable->done()){
            bool cont = statetable->Next();
            if(!cont) break;
            //statetable->Next();
            //cout << statetable->key() << "\t" << statetable->value2() << endl;
           if(statetable->value2() != defaultv){
                partial_curr += static_cast<double>(statetable->value2());
            }
            //partial_curr += abs(static_cast<double>(statetable->value2()));
        }
        return partial_curr;
    }
    
    bool terminate(vector<double> local_reports){
        curr = 0;
        vector<double>::iterator it;
        for(it=local_reports.begin(); it!=local_reports.end(); it++){
                curr += *it;
        }
        
        VLOG(0) << "terminate check : last=" << last << " curr=" << curr << " diff=" << abs(curr-last) << " thre=" << FLAGS_termcheck_threshold;
        cout << "terminate check : last=" << last << " current=" << curr << " diff=" << abs(curr-last) << endl;
        if(abs(curr-last) <= FLAGS_termcheck_threshold){
            //VLOG(0)<<"FLAGS_termcheck_threshold: "<<FLAGS_termcheck_threshold << "currtrue: "<< curr;
            return true;
        }else{
            last = curr;
            //VLOG(0)<<"FLAGS_termcheck_threshold: "<<FLAGS_termcheck_threshold << "curr: "<< curr;
            return false;
        }
    }
  };

static int Katz(ConfigData& conf) {
    MaiterKernel<int, float, vector<int> >* kernel = new MaiterKernel<int, float, vector<int> >(
                                        conf, FLAGS_num_nodes, FLAGS_portion, FLAGS_result_dir,
                                        new Sharding::Mod,
                                        new KatzIterateKernel,
                                        new KatzTermChecker);
    
    
    kernel->registerMaiter();

    if (!StartWorker(conf)) {
        Master m(conf);
        m.run_maiter(kernel);
    }
    
    delete kernel;
    return 0;
}

REGISTER_RUNNER(Katz);


