#ifndef KERNELREGISTRY_H_
#define KERNELREGISTRY_H_

#include "kernel/table.h"
#include "kernel/global-table.h"
#include "kernel/local-table.h"
#include "kernel/table-registry.h"

#include "util/common.h"
#include <boost/function.hpp>
#include <boost/lexical_cast.hpp>

DECLARE_string(graph_dir);
DECLARE_double(termcheck_threshold);

namespace dsm {

template <class K, class V1, class V2, class V3>
class TypedGlobalTable;

class TableBase;
class Worker;

template <class K, class V, class D>
class MaiterKernel;

#ifndef SWIG
class MarshalledMap {
public:
  struct MarshalledValue {
    virtual string ToString() const = 0;
    virtual void FromString(const string& s) = 0;
    virtual void set(const void* nv) = 0;
    virtual void* get() const = 0;
  };

  template <class T>
  struct MarshalledValueT  : public MarshalledValue {
    MarshalledValueT() : v(new T) {}
    ~MarshalledValueT() { delete v; }

    string ToString() const {
      string tmp;
      m_.marshal(*v, &tmp);
      return tmp;
    }

    void FromString(const string& s) {
      m_.unmarshal(s, v);
    }

    void* get() const { return v; }
    void set(const void *nv) {
      *v = *(T*)nv;
    }

    mutable Marshal<T> m_;
    T *v;
  };

  template <class T>
  void put(const string& k, const T& v) {
    if (serialized_.find(k) != serialized_.end()) {
      serialized_.erase(serialized_.find(k));
    }

    if (p_.find(k) == p_.end()) {
      p_[k] = new MarshalledValueT<T>;
    }

    p_[k]->set(&v);
  }

  template <class T>
  T& get(const string& k) const {
    if (serialized_.find(k) != serialized_.end()) {
      p_[k] = new MarshalledValueT<T>;
      p_[k]->FromString(serialized_[k]);
      serialized_.erase(serialized_.find(k));
    }

    return *(T*)p_.find(k)->second->get();
  }

  bool contains(const string& key) const {
    return p_.find(key) != p_.end() ||
           serialized_.find(key) != serialized_.end();
  }

  Args* ToMessage() const {
    Args* out = new Args;
    for (unordered_map<string, MarshalledValue*>::const_iterator i = p_.begin(); i != p_.end(); ++i) {
      Arg *p = out->add_param();
      p->set_key(i->first);
      p->set_value(i->second->ToString());
    }
    return out;
  }

  // We can't immediately deserialize the parameters passed in, since sadly we don't
  // know the type yet.  Instead, save the string values on the side, and de-serialize
  // on request.
  void FromMessage(const Args& p) {
    for (int i = 0; i < p.param_size(); ++i) {
      serialized_[p.param(i).key()] = p.param(i).value();
    }
  }

private:
  mutable unordered_map<string, MarshalledValue*> p_;
  mutable unordered_map<string, string> serialized_;
};
#endif


class DSMKernel {
public:
  // Called upon creation of this kernel by a worker.
  virtual void InitKernel() {}

  // The table and shard being processed.
  int current_shard() const { return shard_; }
  int current_table() const { return table_id_; }

  template <class T>
  T& get_arg(const string& key) const {
    return args_.get<T>(key);
  }

  template <class T>
  T& get_cp_var(const string& key, T defval=T()) {
    if (!cp_.contains(key)) {
      cp_.put(key, defval);
    }
    return cp_.get<T>(key);
  }

  GlobalTable* get_table(int id);

  template <class K, class V1, class V2, class V3>
  TypedGlobalTable<K, V1, V2, V3>* get_table(int id) {
    return dynamic_cast<TypedGlobalTable<K, V1, V2, V3>*>(get_table(id));
  }
  
  template <class K, class V, class D>
  void set_maiter(MaiterKernel<K, V, D> maiter){}
  
private:
  friend class Worker;
  friend class Master;

  void initialize_internal(Worker* w,
                           int table_id, int shard);

  void set_args(const MarshalledMap& args);
  void set_checkpoint(const MarshalledMap& args);

  Worker *w_;
  int shard_;
  int table_id_;
  MarshalledMap args_;
  MarshalledMap cp_;
};

struct KernelInfo {
  KernelInfo(const char* name) : name_(name) {}

  virtual DSMKernel* create() = 0;
  virtual void Run(DSMKernel* obj, const string& method_name) = 0;
  virtual bool has_method(const string& method_name) = 0;

  string name_;
};

template <class C, class K, class V, class D>
struct KernelInfoT : public KernelInfo {
  typedef void (C::*Method)();
  map<string, Method> methods_;
  MaiterKernel<K, V, D>* maiter;

  KernelInfoT(const char* name, MaiterKernel<K, V, D>* inmaiter) : KernelInfo(name) {
      maiter = inmaiter;
  }

  DSMKernel* create() { return new C; }

  void Run(DSMKernel* obj, const string& method_id) {
    ((C*)obj)->set_maiter(maiter);
    boost::function<void (C*)> m(methods_[method_id]);
    m((C*)obj);
  }

  bool has_method(const string& name) {
    return methods_.find(name) != methods_.end();
  }

  void register_method(const char* mname, Method m, MaiterKernel<K, V, D>* inmaiter) { 
      methods_[mname] = m; 
  }
};

class ConfigData;
class KernelRegistry {
public:
  typedef map<string, KernelInfo*> Map;
  Map& kernels() { return m_; }
  KernelInfo* kernel(const string& name) { return m_[name]; }

  static KernelRegistry* Get();
private:
  KernelRegistry() {}
  Map m_;
};

template <class C, class K, class V, class D>
struct KernelRegistrationHelper {
  KernelRegistrationHelper(const char* name, MaiterKernel<K, V, D>* maiter) {
    KernelRegistry::Map& kreg = KernelRegistry::Get()->kernels();

    CHECK(kreg.find(name) == kreg.end());
    kreg.insert(make_pair(name, new KernelInfoT<C, K, V, D>(name, maiter)));
  }
};


template <class C, class K, class V, class D>
struct MethodRegistrationHelper {
  MethodRegistrationHelper(const char* klass, const char* mname, void (C::*m)(), MaiterKernel<K, V, D>* maiter) {
    ((KernelInfoT<C, K, V, D>*)KernelRegistry::Get()->kernel(klass))->register_method(mname, m, maiter);
  }
};

template <class K, class V, class D>
class MaiterKernel0 : public DSMKernel {
private:
    MaiterKernel<K, V, D>* maiter;
public:


    void run() {
        VLOG(0) << "initializing table ";
        init_table(maiter->table);
    }
};

template <class K, class V, class D>
class MaiterKernel1 : public DSMKernel {                    //the first phase: initialize the local state table
private:
    MaiterKernel<K, V, D>* maiter;                          //user-defined iteratekernel
public:
    void set_maiter(MaiterKernel<K, V, D>* inmaiter) {
        maiter = inmaiter;
    }
    
    void read_file(TypedGlobalTable<K, V, V, D>* table){
        string patition_file = StringPrintf("%s/part%d", FLAGS_graph_dir.c_str(), current_shard());
        ifstream inFile;
        inFile.open(patition_file.c_str());
        if (!inFile) {
            cerr << "Unable to open file" << patition_file;
            cerr << system("ifconfig -a | grep 192.168.*")<<endl;
            exit(1); // terminate with error
        }

        char linechr[2024000];
        while (inFile.getline(linechr, 2024000)) {              //read a line of the input file, ensure the buffer is large enough
            K key;
            V delta;
            D data;
            V value;
            string line(linechr);
            maiter->iterkernel->read_data(line, key, data);   //invoke api, get the value of key field and data field
            maiter->iterkernel->init_v(key,value,data);          //invoke api, get the initial v field value
            maiter->iterkernel->init_c(key, delta,data); //invoke api, get the initial delta v field value
            //cout<<"key: "<<key<<"delta: "<<delta<<"value: "<<value<<"   "<<data[0][0]<<"  "<<data[1][0]<<"   "<<data[2][0]<<endl;
            table->put(key, delta, value, data);                //initialize a row of the state table (a node)
        }
    }
    
    void checkpoint_special_load(TypedGlobalTable<K, V, V, D>* a){   
        double load_start_ = Now();
        
        //recover vertex values
        string fckvd_file = StringPrintf("%s/fckvd-%d", FLAGS_graph_dir.c_str(), current_shard());
        ifstream in_ck_file;
        in_ck_file.open(fckvd_file.c_str());
        if (!in_ck_file) {
            cerr << "Unable to open special checkpoint file: " << fckvd_file;
            return;
            //exit(1); // terminate with error
        }

        char ck_linechr[2024000];
        //read a line of the input file, ensure the buffer is large enough
        while (in_ck_file.getline(ck_linechr, 2024000)) {
            K key;
            V delta; 
            V value;
            string ck_line(ck_linechr);
            maiter->iterkernel->read_special_checkpoint(ck_line, key, delta, value);
            maiter->table->updateF1(key, delta);  //perform reset delta_v to the special checkpoint value.
            //update the vertex value v2: find v2 based on k, and then v2=v2+value, here, v2 is zero, 
            //and value is the special checkpoint value, so the final v2=value 
            maiter->table->accumulateF2(key, value);  
        }
        
        cout << " time of loading special checkpoint file: " << (Now()-load_start_) << "seconds, on worker_" << current_shard() << endl;
    }

    void init_table(TypedGlobalTable<K, V, V, D>* a){
        if(!a->initialized()){
            a->InitStateTable();        //initialize the local state table
        }
        a->resize(maiter->num_nodes);   //create local state table based on the input size

        read_file(a);                   //initialize the state table fields based on the input data file
        //checkpoint_special_load(a);
    }

    void run() {
        VLOG(0) << "initializing table ";
        init_table(maiter->table);
    }
};

template <class K, class V, class D>
class MaiterKernel2 : public DSMKernel {                //the second phase: iterative processing of the local state table
private:
    MaiterKernel<K, V, D>* maiter;                  //user-defined iteratekernel
    vector<pair<K, V> >* output;                    //the output buffer          
    
    //add by wzg.
    bool fault_occur_;  //a fault occurs? yes=true, no=false, default=false.
    bool fault_self_;     //i am a failed worker? yes=true, no=false, default=false.
    int  fc_phase_;        //the fault-recovery phase: 0=reset/default/normal, 1=clear, 2=send_original_msgs, 3=reconstruct_delta_v, default=0.
    bool ck_save_;        //save checkpoint? true=yes, false=no.
    int ck_available_;    //the version of most recent checkpoint, zero/0 means there is not available checkpoint.
    V last_sum;             //summing up values when performing updates
    V current_sum;      //summing up values when performing updates
    V sum_bef_failure; //sum before one failure occurs
    double recover_start = 0.0; //record the time when one failure occurs, it is also the starting time of recovery
    
public:
    void set_maiter(MaiterKernel<K, V, D>* inmaiter) {
        maiter = inmaiter;
        
        //add by wzg.
        fault_occur_ = false;
        fault_self_ = false;
        fc_phase_ = 0;
        ck_save_ = false;
        ck_available_ = 0;
    }
    
    /** k=svid, v1=delta, v2=value, v3=out-neighbors */
    void run_iter(const K& k, V &v1, V &v2, D &v3) {
        maiter->iterkernel->process_delta_v(k,v1,v2,v3);                        //user-defined, do nothing for pagerank.
        maiter->table->accumulateF2(k, v1);                                           //update the vertex value v2: find v2 based on k, and then v2=v2+delta_v(v1)   
        maiter->iterkernel->g_func(k,v1,v2 ,v3, output);                         //user-defined, invoke api, send messages based on delta_v(v1) to out-neighbors
        maiter->table->updateF1(k,maiter->iterkernel->default_v());    //perform delta_v=0, reset delta_v after delta_v has been spread out

        typename vector<pair<K, V> >::iterator iter;
        for(iter = output->begin(); iter != output->end(); iter++) {        //send the buffered messages to remote state table
                pair<K, V> kvpair = *iter;
                maiter->table->accumulateF1(kvpair.first, kvpair.second);   //apply the output messages to remote state table
        }
        output->clear();                                                    //clear the output buffer
        //cout << "update" << k << endl;
    }
    
    //add by wzg, used in Phase 1 to reset local graph states.
    void clear_graph_states(TypedGlobalTable<K, V, V, D>* a) {
         typename TypedGlobalTable<K, V, V, D>::Iterator *it = a->get_entirepass_iterator(current_shard());
         if (sum_bef_failure < last_sum) {
             sum_bef_failure = last_sum;
         } //for cascading failures.
         recover_start = Now();
         last_sum = maiter->iterkernel->default_v();
         current_sum = maiter->iterkernel->default_v();
         if(fault_self_) { //i am the failed worker, clear delta_v(v1) and reset v(v2).
             maiter->table->setProgress(current_shard(), static_cast<double>(last_sum), 2);
             checkpoint_load(a);
             string ck_file = StringPrintf("%s/part-%d-ck-%d", FLAGS_graph_dir.c_str(), current_shard(), ck_available_);
              VLOG(1) << " loaded checkpoint: " << ck_file << " on worker_" << current_shard();
          } else {             //i am not the failed worker, update v(v2) using current delta_v(v1), and then clear delta_v(v1)).
              while(!it->done()) {
                  bool cont = it->Next();
                  if(!cont) break;
                  //add by wzg: source_vertex_id, delta (i.e., the sum of received messages), value, out-neighbors.
                  maiter->table->accumulateF2(it->key(), it->value1()); //update vertex value using the most recent delta_value
                  maiter->table->updateF1(it->key(), maiter->iterkernel->default_v()); //clear delta_value
              }
              VLOG(1) << " updated v and cleared delta_v on worker_" << current_shard();
          }
        delete it;
        //checkpoint_special_save(a); //only for testing parallel recovery
    }
    
    //add by wzg, used in Phase 2 to send original messages.
    void send_original_msgs(TypedGlobalTable<K, V, V, D>* a) {
        typename TypedGlobalTable<K, V, V, D>::Iterator *it = a->get_entirepass_iterator(current_shard());
        while(!it->done()) {
            bool cont = it->Next();
            if(!cont) break;
            //add by wzg: source_vertex_id, delta (i.e., the sum of received messages), value, out-neighbors.
            maiter->iterkernel->fc_func(it->key(), it->value1(), it->value2(), it->value3(), output);
            typename vector<pair<K, V> >::iterator iter;
            for(iter = output->begin(); iter != output->end(); iter++) {        //send the buffered messages to remote state table
                pair<K, V> kvpair = *iter;
                maiter->table->accumulateF1(kvpair.first, kvpair.second);   //apply the output messages to remote state table
            }
            output->clear();                                                    //clear the output buffer
        }
        //VLOG(1) << " sent original messages ";
        delete it;
    }
    
    //add by wzg, used in Phase 3 to reconstruct delta_v and then send reconstructed delta_v for all workers.
    void reconstruct_delta_v(TypedGlobalTable<K, V, V, D>* a) {
        typename TypedGlobalTable<K, V, V, D>::Iterator *it = a->get_entirepass_iterator(current_shard());
        while(!it->done()) {
            bool cont = it->Next();
            if(!cont) break;
            //add by wzg: source_vertex_id, delta (i.e., the sum of received messages), value, out-neighbors.
            maiter->iterkernel->fc_recover_delta_v(it->key(), it->value1(), it->value2());
            //NOTE: you mustn't invoke run_iter() to send the reconstructed delta_value here. This work should be done as normal computing
        }
        //VLOG(1) << " reconstructed delta_v ";
        delete it;
    }
    
    //add by wzg, used in Phase 4 to clear values in sending&receiving buffer, and delta_v values.
    void cascading_failure_clear(TypedGlobalTable<K, V, V, D>* a) {
        typename TypedGlobalTable<K, V, V, D>::Iterator *it = a->get_entirepass_iterator(current_shard());
        while(!it->done()) {
            bool cont = it->Next();
            if(!cont) break;
            //add by wzg: source_vertex_id, delta (i.e., the sum of received messages), value, out-neighbors.
            maiter->table->updateF1(it->key(), maiter->iterkernel->default_v()); //set delta_v to "zero"
            //NOTE: you mustn't invoke run_iter() to send the reconstructed delta_value here. This work should be done as normal computing
        }
        //VLOG(1) << " reconstructed delta_v ";
        delete it;
    }
    
    void checkpoint_load(TypedGlobalTable<K, V, V, D>* a){
        //get the sum of current vertex values.
        V sum_bef_failure = maiter->iterkernel->default_v();
        typename TypedGlobalTable<K, V, V, D>::Iterator *it = a->get_entirepass_iterator(current_shard());
        while(!it->done()) {
                bool cont = it->Next();
                if(!cont) break;
                sum_bef_failure = sum_bef_failure + it->value2();
        }
        delete it;
        
        if (ck_available_ <= 0) {
            cerr << " Error!  Fault occurs before writing any checkpoint file!";
            exit(1); //terminate with error
        }
        
        double load_start_ = Now();
        
        //delete the local table and then re-create it, just used in current version.
        a->DeleteStateTable();
        a->InitStateTable();
        a->resize(maiter->num_nodes);
        for (int i = 0; i < ck_available_; i++) {
            a->incVersion_CheckPoint_Available(current_shard());
        } //recover the available checkpoint version.
        
        //recover topology
        string patition_file = StringPrintf("%s/part%d", FLAGS_graph_dir.c_str(), current_shard()); //used to recover the topology
        ifstream in_partition_file;
        in_partition_file.open(patition_file.c_str());
        if (!in_partition_file) {
            cerr << "Unable to open original partition file: " << patition_file;
            exit(1); // terminate with error
        }
        char par_linechr[2024000];
        //read a line of the input file, ensure the buffer is large enough
        while (in_partition_file.getline(par_linechr, 2024000)) {
            K key;
            V delta;
            D data;
            V value;
            string par_line(par_linechr);
            maiter->iterkernel->read_data(par_line, key, data);   //invoke api, get the value of key field and data field
            maiter->iterkernel->init_v(key, value, data);          //invoke api, get the initial v field value
            maiter->iterkernel->init_c(key, delta, data); //invoke api, get the initial delta v field value
            a->put(key, delta, value, data);                //initialize a row of the state table (a node)
        }
        /*
        if (ck_available_ == 1) {
            return;
        }
        */
        //recover vertex values
        string ck_file = StringPrintf("%s/part-%d-ck-%d", FLAGS_graph_dir.c_str(), current_shard(), ck_available_);
        ifstream in_ck_file;
        in_ck_file.open(ck_file.c_str());
        if (!in_ck_file) {
            cerr << "Unable to open checkpoint file: " << ck_file;
            exit(1); // terminate with error
        }

        char ck_linechr[2024000];
        //read a line of the input file, ensure the buffer is large enough
        V sum_in_ck = maiter->iterkernel->default_v();
        while (in_ck_file.getline(ck_linechr, 2024000)) {
            K key;
            V value;
            string ck_line(ck_linechr);
            maiter->iterkernel->read_checkpoint(ck_line, key, value);
            maiter->table->accumulateF2(key, value);                                           //update the vertex value v2: find v2 based on k, and then v2=v2+value, here, v2 is zero, and value is the checkpoint value, so the final v2=value  
            maiter->table->updateF1(key, maiter->iterkernel->default_v());        //perform delta_v=0, reset delta_v
            sum_in_ck = sum_in_ck + value;
        }
        cout << "sum_bef_failure=" << sum_bef_failure << ", sum_in_ck=" << sum_in_ck << ", on worker_" << current_shard() << endl;
        cout << " time of loading original file and ck-file: " << (Now()-load_start_) << "seconds, on worker_" << current_shard() << endl;
    }
    
    //add by wzg, to save checkpoint.
    void checkpoint_save(TypedGlobalTable<K, V, V, D>* a){
        fstream File;                   //the output file containing the local state table infomation
        string file = StringPrintf("%s/part-%d-ck-%d", FLAGS_graph_dir.c_str(), current_shard(), (ck_available_+1));  //the output path
        if (!access(file.c_str(), F_OK)) {
            if (remove(file.c_str())) {
                cerr << " Unable to delete existing checkpoint file: " << file;
                exit(1); // terminate with error
            } else {
                //VLOG(1) << " delete the existing checkpoint file=" << file;
            }
        }
        File.open(file.c_str(), ios::out);
        bool interrupt = false;
        
        //get the iterator of the local state table
        typename TypedGlobalTable<K, V, V, D>::Iterator *it = a->get_entirepass_iterator(current_shard());
        while(!it->done()) {
                if (maiter->table->getFlag_FaultSelf(current_shard())) {
                    interrupt = true;
                    break; //failure occurs when saving a checkpoint, then abandon this checkpoint.
                }
                bool cont = it->Next();
                if(!cont) break;
                File << it->key() << "\t" << it->value2() << "\n"; //only save vid&value, because the topology is constant for PageRank
        }
        delete it;
        File.close();
        
        if (interrupt) {
            file = StringPrintf("%s/part-%d-ck-%d", FLAGS_graph_dir.c_str(), current_shard(), (ck_available_+1));
            if (remove(file.c_str())) {
                cerr << " Unable to delete the failed checkpoint file: " << file;
                exit(1); // terminate with error
            }
        } else {
            if (ck_available_ > 0) {
                file = StringPrintf("%s/part-%d-ck-%d", FLAGS_graph_dir.c_str(), current_shard(), ck_available_);  //the old output path
                if (remove(file.c_str())) {
                    cerr << " Unable to delete the old checkpoint file: " << file;
                    exit(1); // terminate with error
                }
            } //delete the old checkpoint file if it exists
            a->incVersion_CheckPoint_Available(current_shard()); //current version is available.
        }
    }
    
    //add by wzg, to save current vertex values as a special checkpoint,named "fckv_worker_id", preparing to test parallel recovery.
    void checkpoint_special_save(TypedGlobalTable<K, V, V, D>* a){
        fstream File;                   //the output file containing the local state table infomation
        string file = StringPrintf("%s/fckv-%d", FLAGS_graph_dir.c_str(), current_shard());  //the output path
        if (!access(file.c_str(), F_OK)) {
            if (remove(file.c_str())) {
                cerr << " Unable to delete existing special checkpoint file: " << file;
                exit(1); // terminate with error
            } else {
                //VLOG(1) << " delete the existing checkpoint file=" << file;
            }
        }
        File.open(file.c_str(), ios::out);
        bool interrupt = false;
        
        //get the iterator of the local state table
        typename TypedGlobalTable<K, V, V, D>::Iterator *it = a->get_entirepass_iterator(current_shard());
        while(!it->done()) {
                if (maiter->table->getFlag_FaultSelf(current_shard())) {
                    interrupt = true;
                    break; //failure occurs when saving a checkpoint, then abandon this checkpoint.
                }
                bool cont = it->Next();
                if(!cont) break;
                File << it->key() << "\t" << it->value2() << "\n"; //only save vid&value, because the topology is constant for PageRank
        }
        delete it;
        File.close();
        
        if (interrupt) {
            file = StringPrintf("%s/fckv-%d", FLAGS_graph_dir.c_str(), current_shard());
            if (remove(file.c_str())) {
                cerr << " Unable to delete the failed special checkpoint file: " << file;
                exit(1); // terminate with error
            }
        } 
    }
    
    void run_loop(TypedGlobalTable<K, V, V, D>* a) {
        if (recover_start == 0) {
            last_sum = maiter->iterkernel->default_v();
            current_sum = maiter->iterkernel->default_v();
            sum_bef_failure = maiter->iterkernel->default_v();
        }
        
        output = new vector<pair<K, V> >;
        //the main loop for iterative update
        while(true){
            last_sum = current_sum;
            current_sum = maiter->iterkernel->default_v();
            if (recover_start > 0) {
                //recover_start>0 means this worker is failed and re-started
                //VLOG(1) << " sum_bef_failure=" << sum_bef_failure << ", last_sum=" << last_sum << " on worker_" << current_shard();
                if (abs(last_sum-sum_bef_failure)<=FLAGS_termcheck_threshold || last_sum>=sum_bef_failure) {
                    cout << " recovery done! sum_bef_failure=" << sum_bef_failure << ", last_sum=" << last_sum << ", recovery time is: " << (Now()-recover_start) << " seconds, worker_" << current_shard() << endl;
                    recover_start = 0;
                    sum_bef_failure = maiter->iterkernel->default_v(); 
                    maiter->table->setProgress(current_shard(), static_cast<double>(last_sum), 1);  //this worker is failed, and the sum has been recoveried.
                } else {
                    maiter->table->setProgress(current_shard(), static_cast<double>(last_sum), 2);  //this worker is failed, but the sum has not been recoveried.
                }
            } else {
                maiter->table->setProgress(current_shard(), static_cast<double>(last_sum), 0);  //this worker is not failed, normal.
            }
            //set false, no inteligient stop scheme, which can check whether there are changes in statetable
            //get the iterator of the local state table, bool=false as default.
            typename TypedGlobalTable<K, V, V, D>::Iterator *it2 = a->get_typed_iterator(current_shard(), false);
            if(it2 == NULL) {
                break;
            }
            //should not use for(;!it->done();it->Next()), that will skip some entry
            while(!it2->done()) {
                bool cont = it2->Next();        //if we have more in the state table, we continue
                if(!cont) break;
                //add by wzg: source_vertex_id, delta (i.e., the sum of received messages), value, out-neighbors.
                run_iter(it2->key(), it2->value1(), it2->value2(), it2->value3());
                current_sum = current_sum + it2->value2();
            }
            delete it2;                         //delete the table iterator
        }
    }

    void map() {
        fault_occur_ = maiter->table->getFlag_FaultOccur(current_shard());
        fault_self_ = maiter->table->getFlag_FaultSelf(current_shard());
        fc_phase_ = maiter->table->getPhase_FaultRecovery(current_shard());
        ck_save_ = maiter->table->getFlag_CheckPoint_Save(current_shard());
        ck_available_ = maiter->table->getVersion_CheckPoint_Available(current_shard());
        //VLOG(1) << " flags: fault_occur_=" << fault_occur_ << ", fault_self_=" << fault_self_ << ", fc_phase_=" << fc_phase_;
        
        if (fault_occur_) {
            switch(fc_phase_) {
                case 0:
                    //do nothing.
                    break;
                case 1: 
                    //VLOG(1) << " recover in phase_1: reset local graph";
                    clear_graph_states(maiter->table);
                    break;
                case 2: 
                    //VLOG(1) << " recover in phase_2: exchange original messages";
                    send_original_msgs(maiter->table);
                    break;
                case 3: 
                    //VLOG(1) << " recover in phase_3: reconstruct delta values";
                    reconstruct_delta_v(maiter->table);
                    break;
                case 4:
                    //VLOG(1) << " handle cascading failures-->clear values in message sending&receiving buffer and delta_values";
                    cascading_failure_clear(maiter->table);
                    break;
                default: 
                    VLOG(1) << " ERROR: invalid fc_phase=" << fc_phase_ << ", not (0, 1, 2, or 3). ";
            }
        } else if (ck_save_) {
            //VLOG(1) << " start saving checkpoint, version=" << (ck_available_+1);
            checkpoint_save(maiter->table);
            VLOG(1) << " saving checkpoint successfully, version=" << (ck_available_+1);
        } else {
            VLOG(0) << "start performing iterative update";
            run_loop(maiter->table);
            VLOG(0) << "end performing iterative update";  
        }
    }
};

template <class K, class V, class D>
class MaiterKernel3 : public DSMKernel {        //the third phase: dumping the result, write the in-memory table to disk
private:
    MaiterKernel<K, V, D>* maiter;              //user-defined iteratekernel
public:
    void set_maiter(MaiterKernel<K, V, D>* inmaiter) {
        maiter = inmaiter;
    }
        
    void dump(TypedGlobalTable<K, V, V, D>* a){
        double totalF1 = 0;             //the sum of delta_v, it should be smaller enough when iteration converges  
        double totalF2 = 0;             //the sum of v, it should be larger enough when iteration converges
        fstream File;                   //the output file containing the local state table infomation

        string file = StringPrintf("%s/part-%d", maiter->output.c_str(), current_shard());  //the output path
        File.open(file.c_str(), ios::out);

        //get the iterator of the local state table
        typename TypedGlobalTable<K, V, V, D>::Iterator *it = a->get_entirepass_iterator(current_shard());

        while(!it->done()) {
                bool cont = it->Next();
                if(!cont) break;
                
                totalF1 += it->value1();
                totalF2 += it->value2();
                File << it->key() << "\t" << it->value1() << ":" << it->value2() << "\n";
        }
        delete it;
        File.close();
        
        cout << "total F1 : " << totalF1 << " on worker=" << (current_shard()+1) << endl;
        cout << "total F2 : " << totalF2 << " on worker=" << (current_shard()+1) << endl;
    }

    void run() {
        VLOG(0) << "dumping result";
        dump(maiter->table);
    }
};


template <class K, class V, class D>
class MaiterKernel{
    
public:
        
    int64_t num_nodes;
    double schedule_portion;
    ConfigData conf;
    string output;
    Sharder<K> *sharder;
    IterateKernel<K, V, D> *iterkernel;
    TermChecker<K, V> *termchecker;

    TypedGlobalTable<K, V, V, D> *table;

    
    MaiterKernel() { Reset(); }

    MaiterKernel(ConfigData& inconf, int64_t nodes, double portion, string outdir,
                    Sharder<K>* insharder,                  //the user-defined partitioner
                    IterateKernel<K, V, D>* initerkernel,   //the user-defined iterate kernel
                    TermChecker<K, V>* intermchecker) {     //the user-defined terminate checker
        Reset();
        
        conf = inconf;                  //configuration
        num_nodes = nodes;              //local state table size
        schedule_portion = portion;     //priority scheduling, scheduled portion
        output = outdir;                //output dir
        sharder = insharder;            //the user-defined partitioner
        iterkernel = initerkernel;      //the user-defined iterate kernel
        termchecker = intermchecker;    //the user-defined terminate checker
    }
    
    ~MaiterKernel(){}


    void Reset() {
        num_nodes = 0;
        schedule_portion = 1;
        output = "result";
        sharder = NULL;
        iterkernel = NULL;
        termchecker = NULL;
    }


public:
    int registerMaiter() {
	VLOG(0) << "shards (=#workers) " << conf.num_workers();
	table = CreateTable<K, V, V, D >(0, conf.num_workers(), schedule_portion,
                                        sharder, iterkernel, termchecker);
            
        //initialize table job
        KernelRegistrationHelper<MaiterKernel1<K, V, D>, K, V, D>("MaiterKernel1", this);
        MethodRegistrationHelper<MaiterKernel1<K, V, D>, K, V, D>("MaiterKernel1", "run", &MaiterKernel1<K, V, D>::run, this);

        //iterative update job
        if(iterkernel != NULL){
            KernelRegistrationHelper<MaiterKernel2<K, V, D>, K, V, D>("MaiterKernel2", this);
            MethodRegistrationHelper<MaiterKernel2<K, V, D>, K, V, D>("MaiterKernel2", "map", &MaiterKernel2<K, V, D>::map, this);
        }

        //dumping result to disk job
        if(termchecker != NULL){
            KernelRegistrationHelper<MaiterKernel3<K, V, D>, K, V, D>("MaiterKernel3", this);
            MethodRegistrationHelper<MaiterKernel3<K, V, D>, K, V, D>("MaiterKernel3", "run", &MaiterKernel3<K, V, D>::run, this);
        }
     
	return 0;
    }
};


class RunnerRegistry {
public:
  typedef int (*KernelRunner)(ConfigData&);
  typedef map<string, KernelRunner> Map;

  KernelRunner runner(const string& name) { return m_[name]; }
  Map& runners() { return m_; }

  static RunnerRegistry* Get();
private:
  RunnerRegistry() {}
  Map m_;
};

struct RunnerRegistrationHelper {
  RunnerRegistrationHelper(RunnerRegistry::KernelRunner k, const char* name) {
    RunnerRegistry::Get()->runners().insert(make_pair(name, k));
  }
};

#define REGISTER_KERNEL(klass)\
  static KernelRegistrationHelper<klass> k_helper_ ## klass(#klass);

#define REGISTER_METHOD(klass, method)\
  static MethodRegistrationHelper<klass> m_helper_ ## klass ## _ ## method(#klass, #method, &klass::method);

#define REGISTER_RUNNER(r)\
  static RunnerRegistrationHelper r_helper_ ## r ## _(&r, #r);

}
#endif /* KERNELREGISTRY_H_ */
