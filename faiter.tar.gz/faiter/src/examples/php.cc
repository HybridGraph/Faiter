#include "client/client.h"


using namespace dsm;

//DECLARE_string(graph_dir);
DECLARE_string(result_dir);
DECLARE_int64(num_nodes);
DECLARE_double(portion);
DECLARE_int64(php_source);

struct PHPIterateKernel : public IterateKernel<int, float, vector<Link> > {
    float zero;

    PHPIterateKernel() : zero(0){}

    void read_data(string& line, int& k, vector<Link>& data){
        string linestr(line);
        int pos = linestr.find("\t");
        if(pos == -1) return;
        int source = boost::lexical_cast<int>(linestr.substr(0, pos));

        vector<Link> linkvec;
        int spacepos = 0;
        string links = linestr.substr(pos+1);
        while((spacepos = links.find_first_of(" ")) != links.npos){
            Link to(0, 0);
            if(spacepos > 0){
                string link = links.substr(0, spacepos);
                int cut = links.find_first_of(",");
                to.end = boost::lexical_cast<int>(link.substr(0, cut));
                to.weight = boost::lexical_cast<float>(link.substr(cut+1));
            }
            links = links.substr(spacepos+1);
            linkvec.push_back(to);
        }

        k = source;
        data = linkvec;
    }
    
    void read_checkpoint(string& line, int& k, float& v){ 
        string linestr(line);
        int pos = linestr.find("\t");
        if(pos == -1) return;
        
        k = boost::lexical_cast<int>(linestr.substr(0, pos));
        v = boost::lexical_cast<float>(linestr.substr(pos+1));
        //v = 0.0;
        //cout << "read_ck v" << k << "=" << v << endl;
    }
    
    void read_special_checkpoint(string& line, int& k, float& delta, float& v){ 
        string linestr(line);
        int pos = linestr.find("\t");
        if(pos == -1) return;
        k = boost::lexical_cast<int>(linestr.substr(0, pos));
        
        string links = linestr.substr(pos+1);
        pos = links.find("\t");
        if (pos == -1) return;
        delta = boost::lexical_cast<float>(links.substr(0, pos));
        
        v = boost::lexical_cast<float>(links.substr(pos+1));
    }

    void init_c(const int& k, float& delta,vector<Link>& data){
        if (k == FLAGS_php_source) {
            delta = 1;
        } else {
            delta = 0;
        }
    }

    void init_v(const int& k,float& v,vector<Link>& data){
        v=zero;  
    }
    
    void accumulate(float& a, const float& b){
        a = a + b;
    }

    void priority(float& pri, const float& value, const float& delta){
            pri = abs(delta);
    }

    /** Generate messages (i.e., output) for all outgoing neighbors. */
    void g_func(const int& k,const float& delta, const float&value, const vector<Link>& data, vector<pair<int, float> >* output){
        if (delta == 0) {
            return;
        }

        for(vector<Link>::const_iterator it=data.begin(); it!=data.end(); it++){
            Link target = *it;
            float outv = 0.8 * (delta*target.weight);
            if (target.end != FLAGS_php_source) {
                output->push_back(make_pair(target.end, outv));
            }
        }
    }

    const float& default_v() const {
            return zero;
    }
  
    //add by wzg, only used in fault-tolerance, send original messages instead of delta_v
    void fc_func(const int& k,const float& delta,const float& value, const vector<Link>& data, vector<pair<int, float> >* output) {
        if (value == 0) {
            return;
        }
        
        for(vector<Link>::const_iterator it=data.begin(); it!=data.end(); it++) {
            Link target = *it;
            if (target.end != FLAGS_php_source) {
                output->push_back(make_pair(target.end, value*target.weight));
            }
        }
    }
  
    //add by wzg, only used in fault-tolerance
    void fc_recover_delta_v(const int& k, float& delta, float& value) {
        float tmp_v = 0.8*delta; 
        if (k == FLAGS_php_source) {
            tmp_v = tmp_v + 1;
        }
        delta = tmp_v - value;
    }
};

/**
 * K=int, V=float
 */
  struct PHPTermChecker : public TermChecker<int, float> {
    double last;
    double curr;
    
    PHPTermChecker(){
        last = -std::numeric_limits<double>::max();
        curr = 0;
    }

    double set_curr(){
        return curr;
    }
    
    double estimate_prog(LocalTableIterator<int, float>* statetable){
        double partial_curr = 0;
        double defaultv = statetable->defaultV();
        while(!statetable->done()){
            bool cont = statetable->Next();
            if(!cont) break;
            //statetable->Next();
            //cout << statetable->key() << "\t" << statetable->value2() << endl;
           if(statetable->value2() != defaultv){
                partial_curr += static_cast<double>(statetable->value2());
            }
            //partial_curr += abs(static_cast<double>(statetable->value2()));
        }
        return partial_curr;
    }
    
    bool terminate(vector<double> local_reports){
        curr = 0;
        vector<double>::iterator it;
        for(it=local_reports.begin(); it!=local_reports.end(); it++){
                curr += *it;
        }
        
        VLOG(0) << "terminate check : last=" << last << " curr=" << curr << " diff=" << abs(curr-last) << " thre=" << FLAGS_termcheck_threshold;
        cout << "terminate check : last=" << last << " curr=" << curr << " diff=" << abs(curr-last) << endl;
        if(abs(curr-last) <= FLAGS_termcheck_threshold){
            //VLOG(0)<<"FLAGS_termcheck_threshold: "<<FLAGS_termcheck_threshold << "currtrue: "<< curr;
            return true;
        }else{
            last = curr;
            //VLOG(0)<<"FLAGS_termcheck_threshold: "<<FLAGS_termcheck_threshold << "curr: "<< curr;
            return false;
        }
    }
  };

static int PHP(ConfigData& conf) {
    MaiterKernel<int, float, vector<Link> >* kernel = new MaiterKernel<int, float, vector<Link> >(
                                        conf, FLAGS_num_nodes, FLAGS_portion, FLAGS_result_dir,
                                        new Sharding::Mod,
                                        new PHPIterateKernel,
                                        new PHPTermChecker);
    
    
    kernel->registerMaiter();

    if (!StartWorker(conf)) {
        Master m(conf);
        m.run_maiter(kernel);
    }
    
    delete kernel;
    return 0;
}

REGISTER_RUNNER(PHP);
