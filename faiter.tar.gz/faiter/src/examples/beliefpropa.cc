/*
 * beliefpropa.cc
 *
 *  Created on: 2011-12-29
 *      Author: zhangyf
 */

