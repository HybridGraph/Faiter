#ifndef LOCALTABLE_H_
#define LOCALTABLE_H_

#include "table.h"
#include "util/file.h"
#include "util/rpc.h"

namespace dsm {

static const double kLoadFactor = 0.8;

// Represents a single shard of a partitioned global table.
class LocalTable :
  public TableBase,
  virtual public UntypedTable,
  public Checkpointable,
  public Serializable,
  public Transmittable,
  public Snapshottable {
public:
  LocalTable() : delta_file_(NULL) {}
  bool empty() { return size() == 0; }

  void start_checkpoint(const string& f);
  void finish_checkpoint();
  void restore(const string& f);
  void write_delta(const KVPairData& put);
  
  void termcheck(const string& f, long *updates, double *totalF2);

  virtual int64_t size() = 0;
  virtual void clear() = 0;
  virtual void reset() = 0;
  virtual void resize(int64_t size) = 0;

  virtual TableIterator* get_iterator(TableHelper* helper, bool bfilter) = 0;
  virtual TableIterator* schedule_iterator(TableHelper* helper, bool bfilter) = 0;
  virtual TableIterator* entirepass_iterator(TableHelper* helper) = 0;
  //add by wzg, set progress
  virtual void setLocalProgress(double progress, int recoveried) = 0;
   //add by wzg, get the current flag: fault_occur_.
  virtual bool getLocalFlag_FaultOccur() = 0;
  //add by wzg, get the current flag: fault_self_.
  virtual bool getLocalFlag_FaultSelf() = 0;
  //add by wzg, get the current phase: fault-recovery: fc_phase_.
  virtual int getLocalPhase_FaultRecovery() = 0;
  //add by wzg, get the current flag: save_ck? true=yes, false=no.
  virtual bool getLocalFlag_CheckPoint_Save() = 0;
  virtual int getLocalVersion_CheckPoint_Available() = 0;
  virtual void incLocalVersion_CheckPoint_Available() = 0;

  int shard() { return info_.shard; }

protected:
  friend class GlobalTable;
  TableCoder *delta_file_;
};

}

#endif /* LOCALTABLE_H_ */
